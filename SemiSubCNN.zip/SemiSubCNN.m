clear
%% This code is for the prediction and validation of the rms lift coefficient of semi-submersibles. 
%%% The input set comprises of 20 cases.
%%% Inp0.mat contains inputs for the 0 degree angle of attack cases listed below.
%%% Inp45.mat contains inputs for the 45 degree angle of attack cases listed below.
%%% TrainedCNN.mat contains the trained CNN.
%%% CL.mat contains the validation data for cases [1 2 6 8 9 10] in the below 
%%% list for both 0 and 45 degree angles of attack at reduced velocity = 7.0.
%%% The data are obtained from the following paper: "Liu, M., Xiao, L., Yang, 
%%% J. and Tian, X., 2017. Parametric study on the vortex-induced motions of  
%%% semi-submersibles: Effect of rounded ratios of the column and pontoon. 
%%% Physics of Fluids, 29(5), p.055101."
%%% No  Code name       Column shape        Column rounding         Pontoon shape       Pontoon rounding
% % 1   SQC-SQP         Sharp square                0               Sharp rectangular           0	
% % 2   SQC-SRP0.1      Sharp square                0               Rounded rectangular         0.1
% % 3   SRC0.1-SRP0.1	Rounded square              0.1             Rounded rectangular         0.1
% % 4   SRC0.2-SRP0.1	Rounded square              0.2             Rounded rectangular         0.1	
% % 5   SRC0.3-SRP0.1	Rounded square              0.3             Rounded rectangular         0.1	
% % 6   SRC0.5-SQP      Circular                    0.5             Sharp rectangular           0	
% % 7   SRC0.05-SRP0.1	Rounded square              0.05            Rounded rectangular         0.1	
% % 8   SRC0.5-SRP0.1	Circular                    0.5             Rounded rectangular         0.1	
% % 9   SRC0.15-SQP     Rounded square              0.15            Sharp rectangular           0	
% % 10  SRC0.15-SRP0.1	Rounded square              0.15            Rounded rectangular         0.1

load('Inp0.mat')
load('Inp45.mat')
load('TrainedCNN.mat')
load('CL.mat')

CLPre0 = predict(net,Inp0deg);
CLPre45 = predict(net,Inp45deg);

CLreal0 = CL(1:6);
CLreal45 = CL(7:12);
DataPoints = [1 2 6 8 9 10];
plot (DataPoints,CLreal0,'ok','MarkerFaceColor','k')
hold on
plot (DataPoints,CLreal45,'or','MarkerFaceColor','r')
hold on
plot (CLPre0,'--ok')
hold on
plot (CLPre45,'-.or')
hold on
